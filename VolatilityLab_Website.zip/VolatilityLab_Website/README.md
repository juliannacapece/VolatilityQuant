# VolatilityLab

A dark-themed Streamlit quantitative research dashboard built from the cleaned VolatilityLab Colab notebooks.

## Start locally

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Or upload this folder to GitHub and deploy `app.py` with Streamlit Community Cloud.

## Modules

1. AI Forecasting: trailing historical volatility, rolling GARCH(1,1), and log-variance XGBoost.
2. IV Surface: filtered Yahoo Finance option chains, observed contracts, interpolated 3D surface, and 2D smile.
3. Options Hedging: simplified Black–Scholes delta hedging with stock transactions and financing on a hypothetical five-day path.
4. Historical Stress Testing: SPY historical volatility, drawdowns, and selected crisis windows.

## Research limitations

This is an exploratory research website, not an arbitrage-free options pricer or a live trading system. The hedging tab uses simulated stock paths and model estimates rather than real options backtests. The stress tab shows historical market behavior; full rolling crisis forecast comparisons remain in the research notebooks. Yahoo Finance data can be missing, delayed or inconsistent. Refit times and API throttling may affect performance. No investment advice.
